<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
         Schema::create('conges', function (Blueprint $table) {
             $table->id('idConge');
             $table->date('date_debut');
             $table->date('date_fin');
             $table->date('date_demande');
             $table->string('type_conge');
             $table->string('statut');

             $table->foreignId('idPersonnel')
                   ->constrained('personnels', 'idPersonnel')
                   ->onDelete('cascade');

             $table->timestamps();
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('conges');
    }
};
